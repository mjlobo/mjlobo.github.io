let width = 960;
let height = 480;

const svg = d3
  .select("body")
  .append("svg")
  .attr("viewBox", [0, 0, width, height])
  .attr("width", width);

const margin = { top: 25, right: 20, bottom: 40, left: 60 };

let map = null;
async function start() {
  let data = await d3.dsv(
    ";",
    "https://mjlobo.github.io/teaching/mde/data/arbresremarquablesparis.csv"
  );
  let borders = await d3.json(
    "https://mjlobo.github.io/teaching/mde/data/arrondissements.geojson"
  );
  console.log("borders", borders);
  let trees = processTrees(data);
  console.log(trees);
}

start();

function processTrees(trees) {
  var position;
  var date;
  var parseDate = d3.timeParse("%Y-%m-%d");
  trees.forEach(data => {
    data["HAUTEUR"] = +data["HAUTEUR"];
    data["CIRCONFERENCE"] = +data["CIRCONFERENCE"];
    position = data["Geo point"].split(",");
    data["POSITION"] = { lat: +position[0], lon: +position[1] };
    date = data["DATEPLANTATION"].split("T");
    data["DATE"] = parseDate(date[0]);
  });
  return trees;
}
