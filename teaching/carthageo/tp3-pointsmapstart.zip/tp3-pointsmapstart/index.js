let width = 960;
let height = 480;

let widthScatterplot = 400;
let heightScatterplot = 400;

var projection = d3
  .geoConicConformal()
  .center([2.3488, 48.8534])
  .scale(200000)
  .translate([width / 2, height / 2]);

path = d3.geoPath(projection);

const svg = d3
  .select("body")
  .append("svg")
  .attr("viewBox", [0, 0, width, height])
  .attr("width", width);

const margin = { top: 25, right: 20, bottom: 40, left: 60 };

const g = svg.append("g");
let map = null;
async function start() {
  let data = await d3.dsv(
    ";",
    "https://mjlobo.github.io/teaching/mde/data/arbresremarquablesparis.csv"
  );
  let borders = await d3.json(
    "https://mjlobo.github.io/teaching/mde/data/arrondissements.geojson"
  );

  let trees = processTrees(data);
  let treesPerNeighborhood = d3.rollup(trees, v => v.length, d => d.c_ar);

  map = createPointsMap(svg, g, trees, borders);
}

start();

function zoomed(event) {
  const { transform } = event;
  g.attr("transform", transform);
  map.attr("r", 4 / transform.k);
  // g.attr("stroke-width", 1 / transform.k);
}

function processDistric(name) {
  if (name == "BOIS DE BOULOGNE") {
    return 16;
  } else if (name == "BOIS DE VINCENNES") {
    return 12;
  } else {
    return parseInt(name.split(" ")[1].slice(0, -1));
  }
}

function processTrees(trees) {
  var position;
  var date;
  var parseDate = d3.timeParse("%Y-%m-%d");
  trees.forEach(data => {
    data["HAUTEUR"] = +data["HAUTEUR"];
    data["CIRCONFERENCE"] = +data["CIRCONFERENCE"];
    position = data["Geo point"].split(",");
    data["POSITION"] = { lat: +position[0], lon: +position[1] };
    date = data["DATEPLANTATION"].split("T");
    data["DATE"] = parseDate(date[0]);
    data.c_ar = processDistric(data["ARRONDISSEMENT"]);
  });
  return trees;
}

function addBorders(borders) {
  svg.append("g");
  svg
    .append("path")
    .attr("d", path(borders))
    .attr("stroke", "white");
}

function createChoroplethMap(svg, g, data, borders) {
  let maxTrees = d3.max([...data.values()]);
  color = d3.scaleQuantize([0, maxTrees], d3.schemeBlues[9]);

  svg
    .append("g")
    .attr("transform", "translate(610,20)")
    .append(() =>
      legend({
        color,
        title: data.title,
        width: 240,
        ticks: 20,
        tickFormat: ".0f"
      })
    );

  g.append("g")
    .selectAll("path")
    .data(borders.features)
    .join("path")
    .attr("d", path)
    .attr("stroke", "black")
    .attr("fill", d => {
      if (data.has(d.properties.c_ar)) {
        return color(data.get(d.properties.c_ar));
      } else {
        return color(0);
      }
    });
}

function createPointsMap(svg, g, data, borders) {
  g.append("g")
    .selectAll("path")
    .data(borders.features)
    .join("path")
    .attr("d", path)
    .attr("stroke", "black")
    .attr("fill", "whitesmoke");

  let points = g
    .append("g")
    .selectAll("points")
    .data(data)
    .join("circle")
    .attr("cx", d => projection([d.POSITION.lon, d.POSITION.lat])[0])
    .attr("cy", d => projection([d.POSITION.lon, d.POSITION.lat])[1])
    .attr("r", 4)
    .attr("opacity", 0.5)
    .attr("fill", "forestgreen")
    .attr("stroke", "#fff")
    .attr("stroke-width", 0.5)
    .attr("id", d => "point_" + d.OBJECTID)


  return points;
}


